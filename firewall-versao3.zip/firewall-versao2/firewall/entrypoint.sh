#!/bin/bash
/usr/local/bin/firewall.sh

# Manter o container em execução
tail -f /dev/null
